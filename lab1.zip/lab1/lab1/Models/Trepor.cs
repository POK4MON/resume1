﻿namespace lab1.Models
{
    public class Trepor
    {
        public int ID { get; set; }
        public string Title { get; set; }
        public int Year { get; set; }
        public decimal Price { get; set; }
    }
}
