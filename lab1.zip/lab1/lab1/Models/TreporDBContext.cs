﻿using Microsoft.EntityFrameworkCore;

namespace lab1.Models
{
    public class TreporDBContext : DbContext
    {
        public TreporDBContext(DbContextOptions<TreporDBContext> options) :
base(options)
        {
        }
        public DbSet<Trepor> Trepors { get; set; }

    }
}
